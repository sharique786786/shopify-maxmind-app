import express from "express";
import dotenv from "dotenv";
import { Client as MinFraudClient } from "@maxmind/minfraud-api-node";
import fetch from "node-fetch";

dotenv.config();

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3000;

// --- GeoIP from MaxMind API (no .mmdb required) ---
app.get("/geo", async (req, res) => {
  try {
    const ip = req.headers["x-forwarded-for"] || req.socket.remoteAddress;

    const response = await fetch(
      `https://geoip.maxmind.com/geoip/v2.1/country/${ip}`,
      {
        headers: {
          Authorization:
            "Basic " +
            Buffer.from(
              `${process.env.MAXMIND_ACCOUNT}:${process.env.MAXMIND_LICENSE}`
            ).toString("base64"),
        },
      }
    );

    if (!response.ok) {
      const errText = await response.text();
      return res
        .status(response.status)
        .json({ error: "GeoIP lookup failed", details: errText });
    }

    const geo = await response.json();
    res.json({
      ip,
      country: geo.country?.iso_code || "Unknown",
      registered_country: geo.registered_country?.iso_code,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "GeoIP service failed" });
  }
});

// --- Fraud scoring ---
const fraudClient = new MinFraudClient({
  accountId: process.env.MAXMIND_ACCOUNT,
  licenseKey: process.env.MAXMIND_LICENSE,
});

app.post("/fraud-check", async (req, res) => {
  try {
    const { ip, email } = req.body;
    const result = await fraudClient.score({
      device: { ip_address: ip },
      email: { address: email },
    });
    res.json({ riskScore: result.riskScore });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Fraud check failed" });
  }
});

app.listen(PORT, () =>
  console.log(`✅ Server running on http://localhost:${PORT}`)
);
